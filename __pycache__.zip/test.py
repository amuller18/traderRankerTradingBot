# test_queue.py
import asyncio
import pytest
from telegram_bot_direct_swap import TelegramToDiscordBot

@pytest.mark.asyncio
async def test_serial_execution(monkeypatch):
    bot = TelegramToDiscordBot()

    # Fake swap_tokens that records call order
    call_order = []
    async def fake_swap(ca):
        call_order.append(ca)
        await asyncio.sleep(0.1)

    monkeypatch.setattr(bot, "swap_tokens", fake_swap)

    # Pre-fill queue with three fake contracts
    await bot.swap_queue.put("A")
    await bot.swap_queue.put("B")
    await bot.swap_queue.put("C")

    # Start worker and wait until queue drains
    worker = asyncio.create_task(bot._swap_worker())
    await bot.swap_queue.join()           # waits until task_done called 3×
    worker.cancel()

    assert call_order == ["A", "B", "C"]

asyncio.run(test_serial_execution())
